// Fill out your copyright notice in the Description page of Project Settings.

#include "BlasterCharacter.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/WidgetComponent.h"
#include "Net/UnrealNetwork.h"
#include "BlasterLearing/Weapon/Weapon.h"
#include "BlasterLearing/BlasterComponent/CombatComponent.h"
#include "BlasterLearing/BlasterComponent/BufferComponent.h"
#include "Components/CapsuleComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "BlasterAnimInstance.h"
#include "BlasterLearing/BlasterLearing.h"
#include "BlasterLearing/PlayerController/BlasterPlayerController.h"
#include "BlasterLearing/GameMode/BlasterGameMode.h"
#include "TimerManager.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundCue.h"
#include "Particles/ParticleSystemComponent.h"
#include "BlasterLearing/PlayerState/BlasterPlayerState.h"
#include "BlasterLearing/Weapon/WeaponTypes.h"
#include "Components/BoxComponent.h"
#include "BlasterLearing/BlasterComponent/LagCompensationComponent.h"
#include "BlasterLearing/GameState/BlasterGameState.h"
#include "BlasterLearing/PlayerStart/TeamPlayerStart.h"

ABlasterCharacter::ABlasterCharacter()
{
	PrimaryActorTick.bCanEverTick = true;

	MaxHealth = 100.f;
	Health = MaxHealth;
	MaxShield = 100.f;
	Shield = 0.f;
	bElimmed = false;
}

void ABlasterCharacter::BeginPlay()
{
	Super::BeginPlay();
}

void ABlasterCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ABlasterCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

void ABlasterCharacter::OnRep_OverlappingWeapon(AWeapon* LastWeapon)
{
}

void ABlasterCharacter::ServerEquipButtonPressed_Implementation()
{
}

void ABlasterCharacter::OnRep_Health(float LastHealth)
{
}

void ABlasterCharacter::OnRep_Shield(float LastShield)
{
}

void ABlasterCharacter::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABlasterCharacter, OverlappingWeapon);
	DOREPLIFETIME(ABlasterCharacter, Health);
	DOREPLIFETIME(ABlasterCharacter, Shield);
}
