// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BlasterGameMode.h"
#include "TeamsGameMode.generated.h"

/**
 * 
 */
UCLASS()
class BLASTERLEARING_API ATeamsGameMode : public ABlasterGameMode
{
	GENERATED_BODY()
	
};
